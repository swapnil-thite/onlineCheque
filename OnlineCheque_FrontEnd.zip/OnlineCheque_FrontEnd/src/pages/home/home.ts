import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { HomeServiceProvider } from '../../providers/home-service/home-service';
import { File } from '@ionic-native/file';
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  base64Image: string;
  imgSrc: string;
  filename: string;
  var_picture: any;
  flag: any;
  constructor(public navCtrl: NavController, private file: File,
    private camera: Camera, private service: HomeServiceProvider) {

  }

  takePicture() {
    let options: CameraOptions = {
      quality: 100,
      allowEdit: true,
      sourceType: this.camera.PictureSourceType.CAMERA,
      saveToPhotoAlbum: false,
      correctOrientation: true,
      encodingType: this.camera.EncodingType.JPEG,
      destinationType: this.camera.DestinationType.FILE_URI
    };
    this.camera.getPicture(options).then((imageUri) => {
      this.base64Image = imageUri;
      this.filename = this.base64Image.substring(this.base64Image.lastIndexOf('/') + 1);
      let path = this.base64Image.substring(0, this.base64Image.lastIndexOf('/') + 1);
      this.file.readAsDataURL(path, this.filename).then(res => this.var_picture = res);
    })
  }

  submit(image, cheque) {
    this.service.storeUserData(image, cheque).subscribe(obj => {
      if (obj) {
        console.log("Success" + obj);
        const uuidv4 = Date.now()
        this.service.alertMsg("Information", "Your request has been successfully submitted. Your reference id is :"+uuidv4, ['Ok'])
        console.log(this.flag);
        this.var_picture = "";
        this.flag = "";
      }
    }, (error) => {
      console.log(error);
      this.service.alertMsg("Alert", "Error Occured" + error, ['Ok'])
    });
  }
}
