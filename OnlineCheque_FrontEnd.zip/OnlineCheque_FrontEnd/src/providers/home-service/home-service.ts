import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { map } from 'rxjs/operators';
import { AlertController } from 'ionic-angular';
/*
  Generated class for the HomeServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class HomeServiceProvider {

  constructor(public http: Http, private alertCtrl: AlertController, ) {
    console.log('Hello HomeServiceProvider Provider');
  }
  storeUserData(image: string, cheque: string) {
    const headers = new Headers();
    headers.append('Content-type', 'application/json')
    const urlSearchParams = new URLSearchParams();
    
    // urlSearchParams.append('image', image);
    let chequeObj = {
      "chequeNumber": cheque
    }
    // urlSearchParams.append('chequeNumber', cheque);
    // const body1 = urlSearchParams.toString();
    // console.log(body1);
    return this.http.post('http://192.168.0.190:8080/validatecheque', chequeObj, { headers: headers })
      .pipe(map((response: any) => response));

  }
  public alertMsg(title: string, message: string, btnArray: any[]) {
    let alert = this.alertCtrl.create({
      title: title,
      message: message,
      buttons: btnArray,
      cssClass: "alertCls"
    });
    alert.present();
  }
}
